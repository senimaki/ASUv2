pkg install python2;pip2 install bs4;pip2 install requests;pip2 install mechanize;pkg install openssh;pkg install php
